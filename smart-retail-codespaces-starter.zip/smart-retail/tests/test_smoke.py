def test_imports():
    import src.config as _
    import src.data_prep as _
    import src.features as _
    import src.train as _
    import src.inference as _
